# LC Api Extended
Fork of the original [LC_API](https://github.com/u-2018/LC-API)

## Features
- Can do everything that the base API can (i.e. they are fully compatible)
- Updated frequently to newer versions of the base API
- Incognito Mode: Hides ALL your installed mods from other players
- Family Friendly Mode: Hides only the mods classified as [Cheats](https://github.com/u-2018/LC-API/blob/main/CheatDatabase.cs)
